﻿namespace SIS_Ticket_daw.Models
{
    public class ApplicationUser
    {
        public string Nombre { get; set; }
    }
}
